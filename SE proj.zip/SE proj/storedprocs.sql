-- doc of stored procedures : 

-- create stored procedure to insert new data to resident table

delimiter $$
create procedure insert_proc_res(resident_id int,resident_fname varchar(250), 
resident_lname varchar(250),room_num varchar(250), has_guest varchar(250), resident_res_hall varchar(250), resident_email varchar(250))
begin
insert into res_information
(resident_id, resident_fname,resident_lname,room_num,
has_guest, resident_res_hall,resident_email) values
(resident_id, resident_fname, resident_lname, room_num,
has_guest, resident_res_hall, resident_email);
end $$

-- unit test for res
-- call insert_proc_res(1941439,'Cynthia','Ro','102','TRUE','Mako','cr439@mynsu.nova.edu');
-- select * from res_information;


-- procedure to get all from guests
delimiter $$
create procedure `guests_GetAll` ()
BEGIN
	select * from checkinSys.guest_information;
end $$

-- test guests_GetAll
call guests_GetAll();

-- procedure to get all from residents
delimiter $$
create procedure `res_GetAll` ()
BEGIN
	select * from checkinSys.res_information;
end $$

-- test res_GetAll
call res_GetAll();