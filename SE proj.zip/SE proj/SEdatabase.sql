SELECT `attempt2`.`f_name`,
    `attempt2`.`l_name`,
    `attempt2`.`resident_id`,
    `attempt2`.`room_num`,
    `attempt2`.`has_guest`,
    `attempt2`.`resident_res_hall`,
    `attempt2`.`resident_email`,
    `attempt2`.`guest_f_name`,
    `attempt2`.`guest_l_name`,
    `attempt2`.`guest_id`,
    `attempt2`.`dorm_name`,
    `attempt2`.`guest_email`,
    `attempt2`.`checkin_date`,
    `attempt2`.`checkout_date`,
    `attempt2`.`covid_survey`
FROM `dormData`.`attempt2`;
SELECT * FROM dormData.sedata;
SELECT * FROM dormData.attempt2;
