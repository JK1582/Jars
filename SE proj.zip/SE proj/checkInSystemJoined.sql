CREATE DATABASE checkinSystem;

USE checkinSystem;

 CREATE TABLE res_id
     (resident_id int NOT NULL AUTO_INCREMENT,
      resident_fname varchar(250) NOT NULL,
      resident_lname varchar(250) NOT NULL,
      room_num varchar(250) NOT NULL, 
      has_guest varchar(250) NOT NULL, 
      resident_res_hall varchar(250) NOT NULL, 
      resident_email varchar(250) NOT NULL,
      PRIMARY KEY(resident_id)
     );

SELECT * FROM resident_data;


 CREATE TABLE guest_info
     (guest_id int,
      guest_fname varchar(250),
      guest_lname varchar(250),
	  guest_dorm varchar(250),
      guest_email varchar(250),
      checkin_date varchar(250),
      checkout_date varchar(250), 
      covid_survey varchar(250),
      res_id int,
      FOREIGN KEY(res_id)
		REFERENCES resident_data(resident_id)
        ON DELETE CASCADE
     );
SELECT * FROM guest_info;

CREATE DATABASE checkinSys;

USE checkinSys;

 CREATE TABLE res_information
     (resident_id int NOT NULL AUTO_INCREMENT,
      resident_fname varchar(250) NOT NULL,
      resident_lname varchar(250) NOT NULL,
      room_num varchar(250) NOT NULL, 
      has_guest varchar(250) NOT NULL, 
      resident_res_hall varchar(250) NOT NULL, 
      resident_email varchar(250) NOT NULL,
      PRIMARY KEY(resident_id)
     );
CREATE TABLE guest_information
     (res_id int,
      guest_id int,
      guest_fname varchar(250),
      guest_lname varchar(250),
	  guest_dorm varchar(250),
      guest_email varchar(250),
      checkin_date varchar(250),
      checkout_date varchar(250), 
      covid_survey varchar(250),
      FOREIGN KEY(res_id)
		REFERENCES res_information(resident_id)
        ON DELETE CASCADE
     );
SELECT * FROM guest_information;
SELECT * FROM res_information;
SHOW CREATE TABLE checkinSys.res_information;
SHOW CREATE TABLE checkinSys.guest_information;