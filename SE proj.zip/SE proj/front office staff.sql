USE checkinSys;

-- Table: Front Office Staff
CREATE TABLE front_office_staff(id int,
     username varchar(15), 
     password varchar(15),
     PRIMARY KEY(id)); 

select * from front_office_staff;

-- insert records of fort office staff

INSERT INTO front_office_staff
values (1, 'james19', 'rocks');

INSERT INTO front_office_staff(username, password)
values ('kelly34', 'sand');

INSERT INTO front_office_staff(username, password)
values ('jeremey98', 'sand');

INSERT INTO front_office_staff(username, password)
values ('cherL9', 'dixieCup');

INSERT INTO front_office_staff(username, password)
values ('schmidt77', 'sunny');

INSERT INTO front_office_staff(username, password)
values ('jess89', 'newGirl');

INSERT INTO front_office_staff(username, password)
values ('winston33', 'churchill');

INSERT INTO front_office_staff(username, password)
values ('ronaldReg4', 'merica');

INSERT INTO front_office_staff(username, password)
values ('morgan55', 'guitar');

INSERT INTO front_office_staff(username, password)
values ('sommer41', 'waters8');

select * from front_office_staff;
